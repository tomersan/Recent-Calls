Create Table [Calls]
(
  [Call_id] int IDENTITY(1,1) Not Null CONSTRAINT Call_id_pk PRIMARY KEY,
  [Call_Date] DateTime  default GETDATE(),
  [Phone] NVarchar(50) null,
)
go

ALTER TABLE Calls
ADD [IsActive] bit Not null default 1;

alter proc SelectAllCalls
AS
SELECT top 5 * from Calls
WHERE isActive = 1
order by Call_Date DESC

go


create proc insertcall
  @Phone_Number  NVarchar(50)
as
  INSERT into [dbo].Calls
  ([Phone])
  VALUES(@Phone_Number)
go


create proc deletecall
  @Call_id int
as
  update [dbo].Calls
    Set [IsActive] = 0
    WHERE @Call_id  = [Call_id]
go

create proc editcall
  @Call_id int,
  @Phone NVarchar(50)
as
  update [dbo].Calls
    Set [Phone] = @Phone
    WHERE @Call_id  = [Call_id]
go


