import React, { useState , useEffect } from 'react';
import { useParams } from "react-router-dom"
import { useHistory} from 'react-router-dom';

const EditCall = (params) => {

    const { id } = useParams()
    const [NewNumber, setNewNumber] = useState('')

    const history = useHistory()

    const Edit = async (e) => {
        
        e.preventDefault();

        try {
            let phone = {
                "Phone": NewNumber,
            }

            let res = await fetch('/api/recentcalls/editcall/'+ id, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(phone)

            })
            let data = await res.json()
            history.push("/")
            

        }
        catch (err) { console.log(err) }
    }


        return (
            <>
            <center><h1 className='title2'>Edit Call</h1></center>

            <center>
            <form onSubmit={(e) => Edit(e)}>
            <input type="text" value={NewNumber} onInput={(e) => setNewNumber(e.target.value)} />
            <button type="submit">update call</button>
            </form>
            </center>
            </>
        )

}
export default EditCall;