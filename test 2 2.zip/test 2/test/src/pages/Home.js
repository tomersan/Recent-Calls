import React, { useState , useEffect } from 'react';
import Dropdown from 'react-bootstrap/Dropdown'
import { useHistory} from 'react-router-dom';

const Home = () => {

    const [calls, setCalls] = useState(null)
    const [call, setCall] = useState('')
    const history = useHistory()


    const LoadCalls = async () => {
        try {
            let res = await fetch('/api/recentcalls/all', { method: 'GET' })
            let data = await res.json()
            setCalls(data)
        }
        catch (err) { console.log(err) }
    }

    useEffect(() => {

        LoadCalls()
        if(localStorage.getItem("inputPhoneNumber"))
        {
            setCall(JSON.parse(localStorage.getItem("inputPhoneNumber")))
        }

    }, [])

    useEffect(() => {
        localStorage.setItem('inputPhoneNumber', JSON.stringify(call))
    }, [call])


    const Addcall = async (e) => {
        
        e.preventDefault();

        try {
            let phone = {
                "Phone_Number": call,
            }

            let res = await fetch('/api/recentcalls/addcall', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(phone)

            })
            let data = await res.json()
            window.location.reload(true)

        }
        catch (err) { console.log(err) }
    }



    const DeleteCall = async (id) => {
        try {

            let res = await fetch('/api/recentcalls/deletecall/' + id, {
                method: 'delete',
                headers: {
                    'Content-Type': 'application/json'
                },

            })
            let data = await res.json()
            window.location.reload()
        }
        catch (err) { console.log(err) }
    }

    if(calls !== null)
    {
        console.log(calls)
    return (
        <>
           <center> <h1 className='title'>Recent Calls</h1>
            <form onSubmit={(e) => Addcall(e)}>
            <input type="text" value={call} onInput={(e) => setCall(e.target.value)} />
            <button type="submit">add call</button>
            </form>
            </center>
            <Dropdown className='recent-calls'>
                <Dropdown.Toggle variant="success" id="dropdown-basic">
                    recent calls
                </Dropdown.Toggle>
                <Dropdown.Menu className='list-recent-calls' >
                    {
                        calls.map(i => {return(
                            <>
                            <div className='call-row'>
                            <Dropdown.Item className='call'>{i.Phone}</Dropdown.Item>
                            <p>{i.Call_Date}</p>
                            <p className='delete' onClick={(e) => DeleteCall(i.Call_id)} >delete</p>
                            <p className='Edit' onClick={(e) => history.push('/editcall/'+i.Call_id)} >edit</p>
                            </div>
                            </>
                            
                        )})
                    }
                </Dropdown.Menu>
            </Dropdown>
            
        </>
    )
    }
    else
    {
        return <><center><h1>Loading...</h1></center></>
    }
}
export default Home;