import { BrowserRouter, Route, Switch} from 'react-router-dom';
import Home from '../src/pages/Home'
import EditCall from './pages/EditCall';


function App() {

  return (

    
    <div>
      <BrowserRouter>
        <Switch>
          <Route exact path="/" component={Home}/>
          <Route exact path="/editcall/:id" component={EditCall}/>
        </Switch>
      </BrowserRouter>
 
    </div>
  );
}

export default App;
