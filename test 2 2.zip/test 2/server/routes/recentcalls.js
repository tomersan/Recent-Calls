const express = require("express")
const sql = require("mssql")
const config = require("../utils/config")
var route = express.Router()



route.get(`/all`, async (req, res) => {

    let params = req.params
    sql.on(`error`, (error) => res.send(error))

    let db = await sql.connect(config.db)
    let query = await db.request()
        .execute(`SelectAllCalls`)

    let data = await query.recordset
    await db.close()
    res.send(data)
})

module.exports = route


route.post(`/addcall`, async (req, res) => {

    let body = req.body

    sql.on(`error`, (error) => res.send(error))

    let db = await sql.connect(config.db)
    let query = await db.request()
        .input(`Phone_Number`, sql.NVarChar(50), body.Phone_Number)
        .execute(`insertcall`)

    let data = await query

    await db.close()

    res.send(data)

})
route.delete(`/deletecall/:id`, async (req, res) => {

    let params = req.params

    sql.on(`error`, (error) => res.send(error))

    let db = await sql.connect(config.db)
    let query = await db.request()
        .input(`Call_id`, sql.Int, params.id)
        .execute(`deletecall`)

    let data = await query

    await db.close()

    res.send(data)

})
route.put(`/editcall/:id`, async (req, res) => {

    let params = req.params
    let body = req.body

    sql.on(`error`, (error) => res.send(error))

    let db = await sql.connect(config.db)
    let query = await db.request()
        .input(`Call_id`, sql.Int, params.id)
        .input(`Phone`, sql.NVarChar(50), body.Phone)

        .execute(`editcall`)

    let data = await query

    await db.close()

    res.send(data)

})



